import React from 'react'

export default function Map() {
    return (
        <div style={divStyle}>

        </div>
    )
}


const divStyle = {
    height: "60vh"
}