import React from "react";

import Tracks from "../tracks/Tracks";
export default function Index() {
  return (
    <React.Fragment>
      <Tracks />
    </React.Fragment>
  );
}
